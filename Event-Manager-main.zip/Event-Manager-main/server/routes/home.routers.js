const controllers = require('../controllers/');
const router = require('express').Router();

//router.get('/', controllers.home.get);

module.exports = router;