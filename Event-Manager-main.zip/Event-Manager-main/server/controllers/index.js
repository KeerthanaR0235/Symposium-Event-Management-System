const home = require('./home.controller');
const user = require('./user.controller');
const event = require('./event.controller');

module.exports = {
    user,
    event
};